def inverse_score(score):
	return 1.0 - score

def make_prediction_binary(model1, model2, text1, text2):
	score1 = inverse_score(model1.predict(text1)[0][1])
	score2 = inverse_score(model2.predict(text2)[0][1])
	
	pred1 = 1 if score1 > 0.5 else 0
	pred2 = 1 if score2 > 0.5 else 0
	
	if pred1 == pred2 and pred1 == 0:
		return 0
	if pred1 == pred2 and pred1 == 1:
		return 1
	
	return 2

"""
			Дискретний метод
	
	model1, model2 = навчені моделі
	k1, k2 = коефіцієнти відповідних моделей
	indices = список списків:
		[
			[x,y] = межі не пропаганди
			[x,y] = межі пропаганди
			[x,y] = межі додаткової перевірки
		]
"""
def make_prediction_discrete(model1, model2, text1, text2, k1, k2, indices):
	score1 = inverse_score(model1.predict(text1)[0][1])
	score2 = inverse_score(model2.predict(text2)[0][1])
	
	pred = k1 * score1 + k2 * score2
	
	if indices[0][0] <= pred <= indices[0][1]:
		return pred, 0
	if indices[1][0] <= pred <= indices[1][1]:
		return pred, 1
	
	return pred, 2
