import os
import gi
gi.require_version("Gtk", "3.0")
from gi.repository import GLib, Gtk
import tensorflow as tf
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense, Dropout, Bidirectional
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, recall_score, confusion_matrix
from keras.models import save_model, load_model
import numpy as np
import pickle
import re
import evaluation
import training
import preprocessing
import localization
import file_reading
import threading
from gtkprint import text_view_buff_set_text
from queue import Queue

last_trained_model = None
last_trained_model1 = None
last_tokenizer = None
last_tokenizer1 = None
last_maxlen = None

last_loaded_texts = None
last_loaded_labels = None

def valid_str(text):
	for i in range(len(text)):
		if text[i] not in '0123456789':
			return i
	
	return -1

def on_intnum_entry_changed(widget):
	buf = widget.get_buffer()
	text = buf.get_text()
	if len(text) >= 1:
		valid_status = valid_str(text)
		if valid_status != -1:
			text = text[: valid_status] + text[valid_status + 1:]
			buf.set_text(text, -1)

def valid_str_range(text):
	placed_dots = 0
	for i in range(len(text)):
		if text[i] == '.':
			placed_dots += 1
		if text[i] == ',' or text[i] == ' ':
			placed_dots = 0
		
		if placed_dots >= 2 or text[i].isalpha():
			return i
	
	return -1

def parse_dcfg(filename):
	prop_dir = None
	norm_dir = None
	with open(filename, 'r', encoding='UTF-8') as cfg:
		for line in cfg:
			line = line.rstrip()
			tokens = line.split('=')
			if tokens[0] == 'path_prop':
				prop_dir = tokens[1]
			if tokens[0] == 'path_nonprop':
				norm_dir = tokens[1]
	return prop_dir, norm_dir

def file_cdialog_invocation(win, win_title):
	dialog = Gtk.FileChooserDialog(
		title=win_title, parent=win, action=Gtk.FileChooserAction.OPEN
	)
	dialog.add_buttons(
		Gtk.STOCK_CANCEL,
		Gtk.ResponseType.CANCEL,
		Gtk.STOCK_OPEN,
		Gtk.ResponseType.OK,
	)

	filter_any = Gtk.FileFilter()
	filter_any.set_name("Файл")
	filter_any.add_pattern("*")
	dialog.add_filter(filter_any)

	filename = None
	response = dialog.run()
	if response == Gtk.ResponseType.OK:
		filename = dialog.get_filename()

	dialog.destroy()
	
	return filename

def dir_cdialog_invocation(win, win_title):
	dialog = Gtk.FileChooserDialog(
		title=win_title, parent=win, action=Gtk.FileChooserAction.SELECT_FOLDER
	)
	dialog.add_buttons(
		Gtk.STOCK_CANCEL,
		Gtk.ResponseType.CANCEL,
		Gtk.STOCK_OPEN,
		Gtk.ResponseType.OK,
	)

	filename = None
	response = dialog.run()
	if response == Gtk.ResponseType.OK:
		filename = dialog.get_filename()

	dialog.destroy()
	
	return filename

def on_range_entry_changed(widget):
	buf = widget.get_buffer()
	text = buf.get_text()
	if len(text) >= 1:
		valid_status = valid_str_range(text)
		if valid_status != -1:
			text = text[: valid_status] + text[valid_status + 1:]
			buf.set_text(text, -1)

def ld_tokenizer(path):
	if not os.path.exists(path):
		return "", None
	dest = None
	with open(path, 'rb') as handle:
		dest = pickle.load(handle)
	return path, dest

def ld_model(path):
	if not os.path.exists(path):
		return "", None
	return path, load_model(path)

def get_indices(text):
	tokens = text.split(',')
	return [float(tokens[0]), float(tokens[-1])]

class ValSetLoadWindow(Gtk.Window):
	def __init__(self):
		super().__init__(title="Модуль завантаження валідаційних даних")
		super().set_default_size(300, 250)
		self.vdtype = 0
		self.layout = Gtk.Fixed()
		
		self.l_interp = Gtk.Label(label="Трактувати як...")
		self.l_seps = Gtk.Label(label="Розділювачі")
		self.l_cols = Gtk.Label(label="Стовпці")
		
		self.button_fd = Gtk.Button(image=Gtk.Image.new_from_icon_name(icon_name="folder-symbolic", size=4))
		self.button_ldd = Gtk.Button(label="Завантажити")
		
		self.entry_dpath = Gtk.Entry()
		self.entry_dpath.set_editable(False)
		self.dp_buff = self.entry_dpath.get_buffer()
		self.entry_sep = Gtk.Entry()
		self.sep_buff = self.entry_sep.get_buffer()
		self.entry_ucols = Gtk.Entry()
		self.col_buff = self.entry_ucols.get_buffer()
		
		self.rb_svfile = Gtk.RadioButton.new_with_label_from_widget(None, ".*sv файл")
		self.rb_dir = Gtk.RadioButton.new_with_label_from_widget(self.rb_svfile, "папку")
		
		self.txt_entry_scroll = Gtk.ScrolledWindow()
		self.txt_entry_scroll.set_hexpand(True)
		self.txt_entry_scroll.set_vexpand(True)
		self.txt_entry_scroll.set_size_request(300, 96)
		
		self.txt_entry = Gtk.TextView()
		self.txt_entry.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
		self.txt_entry.set_editable(False)
		self.curtext_buffer = self.txt_entry.get_buffer()
		self.txt_entry_scroll.add(self.txt_entry)
		self.curtext_buffer.set_text("Завантажені дані:\n")
		
		self.entry_sep.set_width_chars(16)
		self.entry_ucols.set_width_chars(16)
		self.entry_dpath.set_width_chars(32)
		self.layout.put(self.entry_dpath, 2, 2)
		self.layout.put(self.l_interp, 0, 32)
		self.layout.put(self.l_seps, 32, 96)
		self.layout.put(self.l_cols, 200, 96)
		self.layout.put(self.rb_svfile, 0, 48)
		self.layout.put(self.rb_dir, 0, 64)
		self.layout.put(self.entry_sep, 0, 112)
		self.layout.put(self.entry_ucols, 164, 112)
		self.layout.put(self.txt_entry_scroll, 0, 172)
		
		self.button_ldd.set_size_request(300, 24)
		self.layout.put(self.button_fd, 270, 0)
		self.layout.put(self.button_ldd, 0, 144)
		
		self.button_fd.connect('clicked', self.find_set_invoke)
		self.button_ldd.connect('clicked', self.load_set_invoke)
		self.rb_svfile.connect('toggled', self.toggle_ftype, 0)
		self.rb_dir.connect('toggled', self.toggle_ftype, 1)
		
		self.add(self.layout)
		self.show_all()
		
	def load_set_invoke(self, widget):
		global last_loaded_texts
		global last_loaded_labels
		
		if not self.dp_buff.get_text():
			return
		
		if self.vdtype == 0:
			separators = file_reading.parse_separators(self.sep_buff.get_text())
			if separators == None:
				return
			
			active_cols = file_reading.parse_active_columns(self.col_buff.get_text())
			if active_cols == None:
				return
			
			last_loaded_texts, last_loaded_labels, translate_list = file_reading.read_separated_values(self.dp_buff.get_text(), separators, active_cols)
			last_loaded_texts = preprocessing.translate_texts(last_loaded_texts, translate_list)
		else:
			last_loaded_texts, last_loaded_labels = file_reading.read_directory(self.dp_buff.get_text())
		self.curtext_buffer.set_text("Завантажені дані:\n")
		count_nonprop = last_loaded_labels.count(0)
		count_prop = last_loaded_labels.count(1)
		self.curtext_buffer.insert(self.curtext_buffer.get_end_iter(), "Текстів, що належать класу 0: {}\nТекстів, що належать класу 1: {}".format(count_nonprop, count_prop))
	
	def toggle_ftype(self, widget, ftype):
		if widget.get_active():
			if self.vdtype != ftype and len(self.dp_buff.get_text()) > 0:
				self.dp_buff.set_text("", -1)
			self.vdtype = ftype
			
			if self.vdtype == 1:
				self.l_cols.hide()
				self.l_seps.hide()
				self.entry_sep.hide()
				self.entry_ucols.hide()
				
				self.layout.move(self.txt_entry_scroll, 0, 124)
				self.layout.move(self.button_ldd, 0, 96)
			else:
				self.show_all()
				
				self.layout.move(self.txt_entry_scroll, 0, 172)
				self.layout.move(self.button_ldd, 0, 144)
	
	def find_set_invoke(self, widget):
		if self.vdtype == 0:
			filename = file_cdialog_invocation(self, "Вибрати .*sv файл...")
		else:
			filename = dir_cdialog_invocation(self, "Вибрати розмічені папки...")
		
		if filename == None:
			return
		self.dp_buff.set_text(filename, -1)

class MLSettingsWindow(Gtk.Window):
	def __init__(self):
		super().__init__(title="Модуль навчання нейромережі")
		super().set_default_size(300, 386)
		self.model_choice = 0 #GRU
		self.prop_dir = None
		self.norm_dir = None
		
		self.preprocessing_thread = None
		self.train_thread = None
		
		self.l_name = Gtk.Label(label="Назва")
		self.l_cbatch = Gtk.Label(label="Розмір пачки")
		self.l_cepoch = Gtk.Label(label="Кількість епох")
		self.l_arch = Gtk.Label(label="Архітектура")
		self.l_dpath = Gtk.Label(label="Шлях до датасету")
		self.l_embsz = Gtk.Label(label="Embedding")
		self.l_rnnun = Gtk.Label(label="Units")
		self.l_vocsz = Gtk.Label(label="Розм. словника")
		
		self.layout = Gtk.Fixed()
		self.name_entry = Gtk.Entry()
		self.ne_buff = self.name_entry.get_buffer()
		self.ne_buff.set_text("model", -1)
		self.cbatch_entry = Gtk.Entry()
		self.cbe_buff = self.cbatch_entry.get_buffer()
		self.cbe_buff.set_text("32", -1)
		self.cepoch_entry = Gtk.Entry()
		self.cpe_buff = self.cepoch_entry.get_buffer()
		self.cpe_buff.set_text("10", -1)
		self.embsize_entry = Gtk.Entry()
		self.esze_buff = self.embsize_entry.get_buffer()
		self.esze_buff.set_text("64", -1)
		self.cuints_entry = Gtk.Entry()
		self.ce_buff = self.cuints_entry.get_buffer()
		self.ce_buff.set_text("64", -1)
		self.vsz_entry = Gtk.Entry()
		self.vsz_buff = self.vsz_entry.get_buffer()
		self.vsz_buff.set_text("1000", -1)
		self.dpath_entry = Gtk.Entry()
		self.dpath_buf = self.dpath_entry.get_buffer()
		self.dpath_buf.set_text('', -1)
		self.dpath_entry.set_editable(False)
		
		self.btnldd_image = Gtk.Image.new_from_icon_name(icon_name="folder-symbolic", size=4)
		
		self.button_train = Gtk.Button(label="Навчити")
		self.button_save = Gtk.Button(label="Зберегти")
		self.button_ldtd = Gtk.Button(label="Валід. дані...")
		self.button_insp = Gtk.Button(label="Досл. ефективність")
		self.button_ldd = Gtk.Button(image=self.btnldd_image)
		
		self.txt_entry_scroll = Gtk.ScrolledWindow()
		self.txt_entry_scroll.set_hexpand(True)
		self.txt_entry_scroll.set_vexpand(True)
		self.txt_entry_scroll.set_size_request(368, 128)
		
		self.txt_entry = Gtk.TextView()
		self.txt_entry.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
		self.txt_entry.set_editable(False)
		self.curtext_buffer = self.txt_entry.get_buffer()
		self.txt_entry_scroll.add(self.txt_entry)
		
		self.model_store = Gtk.ListStore(str)
		self.model_store.append(['GRU'])
		self.model_store.append(['BiLSTM'])
		
		self.renderer_text = Gtk.CellRendererText()
		self.model_combo = Gtk.ComboBox.new_with_model(self.model_store)
		self.model_combo.pack_start(self.renderer_text, True)
		self.model_combo.add_attribute(self.renderer_text, "text", 0)
		self.model_combo.set_active(0)
		self.model_combo.set_entry_text_column(0)
		
		self.vsz_entry.set_width_chars(5)
		self.layout.put(self.name_entry, 118, 0)
		self.layout.put(self.cepoch_entry, 118, 32)
		self.layout.put(self.cbatch_entry, 118, 64)
		self.layout.put(self.dpath_entry, 118, 96)
		self.layout.put(self.model_combo, 118, 128)
		self.layout.put(self.embsize_entry, 118, 160)
		self.layout.put(self.cuints_entry, 118, 192)
		self.layout.put(self.vsz_entry, 298, 128)
		self.layout.put(self.l_name, 0, 0)
		self.layout.put(self.l_cepoch, 0, 32)
		self.layout.put(self.l_cbatch, 0, 64)
		self.layout.put(self.l_dpath, 0, 96)
		self.layout.put(self.l_arch, 0, 128)
		self.layout.put(self.l_embsz, 0, 160)
		self.layout.put(self.l_rnnun, 0, 192)
		self.layout.put(self.l_vocsz, 198, 132)
		
		self.layout.put(self.button_train, 0, 226)
		self.layout.put(self.button_save, 66, 226)
		self.layout.put(self.button_insp, 235, 226)
		self.layout.put(self.button_ldd, 275, 96)
		self.layout.put(self.button_ldtd, 139, 226)
		
		self.layout.put(self.txt_entry_scroll, 0, 258)
		
		self.cepoch_entry.connect("changed", on_intnum_entry_changed)
		self.cbatch_entry.connect("changed", on_intnum_entry_changed)
		self.embsize_entry.connect("changed", on_intnum_entry_changed)
		self.cuints_entry.connect("changed", on_intnum_entry_changed)
		self.vsz_entry.connect("changed", on_intnum_entry_changed)
		self.button_train.connect("clicked", self.trigger_training)
		self.button_insp.connect("clicked", self.trigger_efficiency_test)
		self.button_save.connect("clicked", self.trigger_msave)
		self.button_ldd.connect("clicked", self.dload_clicked)
		self.button_ldtd.connect("clicked", self.val_dload_clicked)
		self.model_combo.connect("changed", self.on_model_combo_changed)
		
		self.add(self.layout)
		self.show_all()
		
	def on_model_combo_changed(self, widget):
		self.model_choice = widget.get_active()
		
	
	def val_dload_clicked(self, widget):
		vslw = ValSetLoadWindow()
	
	def trigger_training(self, widget):
		global last_trained_model
		global last_tokenizer
		global last_maxlen
		
		if self.prop_dir == None or self.norm_dir == None:
			return
		
		model_arch_name = self.model_combo.get_active_iter()
		model_arch_name = self.model_combo.get_model()[model_arch_name][0]
		
		vocsize = int(self.vsz_buff.get_text()) if len(self.vsz_buff.get_text()) >= 1 else 0
		epochs = int(self.cpe_buff.get_text()) if len(self.cpe_buff.get_text()) >= 1 else 0
		batch_sz = int(self.cbe_buff.get_text()) if len(self.cbe_buff.get_text()) >= 1 else 0
		embsize = int(self.esze_buff.get_text()) if len(self.esze_buff.get_text()) >= 1 else 0
		unitc = int(self.ce_buff.get_text()) if len(self.ce_buff.get_text()) >= 1 else 0
		if vocsize == 0 or epochs == 0 or batch_sz == 0 or embsize == 0 or unitc == 0:
			return
		
		text_view_buff_set_text(self.curtext_buffer, "Запуск навчання моделі {}...".format(model_arch_name))
		
		def data_preproc_async():
			preproc_ret = preprocessing.dataset_lnp(self.prop_dir, self.norm_dir, vocsize, self.curtext_buffer)
			result_queue.put(preproc_ret)
			GLib.idle_add(text_view_buff_set_text, self.curtext_buffer, "Успішно завантажено датасет...")
		
		def model_train_async():
			global last_trained_model
			global last_tokenizer
			global last_maxlen
			
			last_tokenizer, X_train, X_test, y_train, y_test, last_maxlen, class_weights, embedding_input_dim = result_queue.get()
			if self.model_choice:
				last_trained_model = training.train_bilstm(X_train, y_train, X_test, y_test, epochs, batch_sz, embsize, embedding_input_dim, unitc, last_maxlen, class_weights) 
			else:
				last_trained_model = training.train_gru(X_train, y_train, X_test, y_test, epochs, batch_sz, embsize, embedding_input_dim, unitc, last_maxlen, class_weights) 
			GLib.idle_add(text_view_buff_set_text, self.curtext_buffer, "Успішно навчено модель {}...".format(model_arch_name))
			
		result_queue = Queue()
		self.preprocessing_thread = threading.Thread(target=data_preproc_async)
		self.preprocessing_thread.start()
		
		self.train_thread = threading.Thread(target=model_train_async)
		self.train_thread.start()
		
	
	def trigger_efficiency_test(self, widget):
		global last_trained_model
		global last_tokenizer
		global last_loaded_labels
		global last_loaded_texts
		global last_maxlen
		
		if last_trained_model == None or last_tokenizer == None or last_maxlen == None or last_loaded_labels == None or last_loaded_texts == None:
			text_view_buff_set_text(self.curtext_buffer, "Неможливо дослідити ефективність:\nМожливо, немає останньої тренованої моделі та її токенізатора\nАбо тестовий датасет не було завантажено.")
			return
		
		texts = preprocessing.create_sequences(last_loaded_texts, last_tokenizer, last_maxlen)
		texts = np.array(texts)
		
		predictions = [prediction[1] for prediction in last_trained_model.predict(np.squeeze(texts, axis=1))]
		predictions = [evaluation.inverse_score(prediction) for prediction in predictions]
		predictions = [1 if score > 0.5 else 0 for score in predictions]
		
		score_accuracy = accuracy_score(last_loaded_labels, predictions)
		score_f1 = f1_score(last_loaded_labels, predictions)
		score_recall = recall_score(last_loaded_labels, predictions)
		conf_mat = confusion_matrix(last_loaded_labels, predictions)
		conf_mat = conf_mat / conf_mat.sum(axis=1)[:, np.newaxis]
		
		text_view_buff_set_text(self.curtext_buffer, "Точність: {}\nОцінка F1: {}\nОцінка Recall: {}\nСплутування:\n{}\n".format(score_accuracy, score_f1, score_recall, conf_mat))
		
	
	def trigger_msave(self, widget):
		global last_trained_model
		global last_tokenizer
		global last_maxlen
		
		mname = self.name_entry.get_text()
		if not mname or last_trained_model == None or last_tokenizer == None or last_maxlen == None:
			return
		
		save_model(last_trained_model, str(int(last_maxlen)) + '_' + mname)
		with open('tokenizer_{}.pickle'.format(mname), 'wb') as handle:
			pickle.dump(last_tokenizer, handle, protocol=pickle.HIGHEST_PROTOCOL)
	
	def dload_clicked(self, widget):
		filename = file_cdialog_invocation(self, "Вибрати конфіг датасету...")
		if filename == None:
			return
		self.dpath_buf.set_text(filename, -1)
		self.prop_dir, self.norm_dir = parse_dcfg(filename)
	

class DetectionWindow(Gtk.Window):
	def __init__(self):
		super().__init__(title="Модуль виявлення пропаганди")
		super().set_default_size(360, 386)
		self.chosen_method = 0 #DISCRETE
		self.last_loaded_model1_path = ""
		self.last_loaded_model2_path = ""
		self.last_loaded_tokenizer1_path = ""
		self.last_loaded_tokenizer2_path = ""
		
		self.layout = Gtk.Fixed()
		
		self.mpath_entry1 = Gtk.Entry()
		self.mpath_entry1.set_editable(False)
		self.mpath_entry2 = Gtk.Entry()
		self.mpath_entry2.set_editable(False)
		self.tpath_entry1 = Gtk.Entry()
		self.tpath_entry1.set_editable(False)
		self.tpath_entry2 = Gtk.Entry()
		self.tpath_entry2.set_editable(False)
		self.mpath_buf1 = self.mpath_entry1.get_buffer()
		self.mpath_buf2 = self.mpath_entry2.get_buffer()
		self.tpath_buf1 = self.tpath_entry1.get_buffer()
		self.tpath_buf2 = self.tpath_entry2.get_buffer()
		
		self.maxlen_entry1 = Gtk.Entry()
		self.ml1_buff = self.maxlen_entry1.get_buffer()
		self.ml1_buff.set_text("512", -1)
		self.maxlen_entry2 = Gtk.Entry()
		self.ml2_buff = self.maxlen_entry2.get_buffer()
		self.ml2_buff.set_text("512", -1)
		
		self.l_nn1 = Gtk.Label(label="Модель №1")
		self.l_nn2 = Gtk.Label(label="Модель №2")
		self.l_tok1 = Gtk.Label(label="Токенізатор №1")
		self.l_tok2 = Gtk.Label(label="Токенізатор №2")
		self.l_maxl1 = Gtk.Label(label="Maxlen")
		self.l_maxl2 = Gtk.Label(label="Maxlen")
		self.l_prop = Gtk.Label(label="Пропаганда")
		self.l_nonprop = Gtk.Label(label="Не пропаганда")
		self.l_sus = Gtk.Label(label="Підозрілий")
		self.l_indices = Gtk.Label(label="Межі")
		self.l_k1 = Gtk.Label(label="K1")
		self.l_k2 = Gtk.Label(label="K2")
		self.score_label = Gtk.Label(label="Оцінка допису: ----")
		
		self.chbutton_translate = Gtk.CheckButton(label="Перекласти")
		self.button_ldnn1 = Gtk.Button(image=Gtk.Image.new_from_icon_name(icon_name="folder-symbolic", size=4))
		self.button_ldnn2 = Gtk.Button(image=Gtk.Image.new_from_icon_name(icon_name="folder-symbolic", size=4))
		self.button_ldt1 = Gtk.Button(image=Gtk.Image.new_from_icon_name(icon_name="folder-symbolic", size=4))
		self.button_ldt2 = Gtk.Button(image=Gtk.Image.new_from_icon_name(icon_name="folder-symbolic", size=4))
		self.button_anlz = Gtk.Button(label='Виконати аналіз')
		
		self.method_store = Gtk.ListStore(str)
		self.method_store.append(['Дискретний метод'])
		self.method_store.append(['Бінарний метод'])
		
		self.renderer_text = Gtk.CellRendererText()
		self.method_combo = Gtk.ComboBox.new_with_model(self.method_store)
		self.method_combo.pack_start(self.renderer_text, True)
		self.method_combo.add_attribute(self.renderer_text, "text", 0)
		self.method_combo.set_active(0)
		
		self.k_adj = Gtk.Adjustment(value=0, lower=-0.5, upper=0.5, step_increment=0.01, page_increment=0.1, page_size=0)
		self.slider_k_adj = Gtk.Scale(orientation=Gtk.Orientation.HORIZONTAL, adjustment=self.k_adj)
		
		self.entry_prop_indices = Gtk.Entry()
		self.entry_prop_indices.set_text('0.6,1.0')
		self.entry_nonprop_indices = Gtk.Entry()
		self.entry_nonprop_indices.set_text('0.0,0.4')
		self.entry_sus_indices = Gtk.Entry()
		self.entry_sus_indices.set_text('0.4,0.6')
		self.pi_buff = self.entry_prop_indices.get_buffer()
		self.npi_buff = self.entry_nonprop_indices.get_buffer()
		self.si_buff = self.entry_sus_indices.get_buffer()
		self.entry_maxlen1 = Gtk.Entry()
		self.entry_maxlen2 = Gtk.Entry()
		
		self.txt_entry_scroll = Gtk.ScrolledWindow()
		self.txt_entry_scroll.set_hexpand(True)
		self.txt_entry_scroll.set_vexpand(True)
		self.txt_entry_scroll.set_size_request(368, 96)
		
		self.txt_entry = Gtk.TextView()
		self.txt_entry.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
		self.txt_entry.set_editable(True)
		self.curtext_buffer = self.txt_entry.get_buffer()
		self.txt_entry_scroll.add(self.txt_entry)
		self.curtext_buffer.set_text("Допис для аналізу...")
		
		self.maxlen_entry1.set_width_chars(12)
		self.maxlen_entry2.set_width_chars(12)
		self.mpath_entry1.set_width_chars(19)
		self.mpath_entry2.set_width_chars(19)
		self.tpath_entry1.set_width_chars(19)
		self.tpath_entry2.set_width_chars(19)
		self.entry_prop_indices.set_width_chars(5)
		self.entry_nonprop_indices.set_width_chars(5)
		self.entry_sus_indices.set_width_chars(5)
		self.slider_k_adj.set_size_request(169, 24)
		self.layout.put(self.l_nn1, 0, 0)
		self.layout.put(self.l_nn2, 196, 0)
		self.layout.put(self.l_tok1, 0, 48)
		self.layout.put(self.l_tok2, 196, 48)
		self.layout.put(self.l_maxl1, 0, 96)
		self.layout.put(self.l_maxl2, 196, 96)
		self.layout.put(self.maxlen_entry1, 48, 94)
		self.layout.put(self.maxlen_entry2, 244, 94)
		self.layout.put(self.mpath_entry1, 0, 18)
		self.layout.put(self.mpath_entry2, 196, 18)
		self.layout.put(self.tpath_entry1, 0, 64)
		self.layout.put(self.tpath_entry2, 196, 64)
		self.layout.put(self.button_ldnn1, 154, 14)
		self.layout.put(self.button_ldnn2, 350, 14)
		self.layout.put(self.button_ldt1, 154, 60)
		self.layout.put(self.button_ldt2, 350, 60)
		self.layout.put(self.method_combo, 120, 124)
		self.layout.put(self.l_k1, 95, 170)
		self.layout.put(self.l_k2, 282, 170)
		self.layout.put(self.l_indices, 180, 194)
		self.layout.put(self.slider_k_adj, 112, 156)
		self.layout.put(self.entry_nonprop_indices, 86, 215)
		self.layout.put(self.entry_sus_indices, 175, 215)
		self.layout.put(self.entry_prop_indices, 250, 215)
		self.layout.put(self.l_nonprop, 65, 240)
		self.layout.put(self.l_sus, 165, 240)
		self.layout.put(self.l_prop, 240, 240)
		self.layout.put(self.txt_entry_scroll, 6, 260)
		self.layout.put(self.score_label, 6, 362)
		self.layout.put(self.button_anlz, 140, 380)
		self.layout.put(self.chbutton_translate, 8, 380)
		
		
		self.maxlen_entry1.connect('changed', on_intnum_entry_changed)
		self.maxlen_entry2.connect('changed', on_intnum_entry_changed)
		self.entry_prop_indices.connect('changed', on_range_entry_changed)
		self.entry_nonprop_indices.connect('changed', on_range_entry_changed)
		self.button_ldnn1.connect('clicked', self.mselect1_invoke)
		self.button_ldnn2.connect('clicked', self.mselect2_invoke)
		self.button_ldt1.connect('clicked', self.tselect1_invoke)
		self.button_ldt2.connect('clicked', self.tselect2_invoke)
		self.entry_sus_indices.connect('changed', on_range_entry_changed)
		self.button_anlz.connect('clicked', self.do_analysis)
		self.method_combo.connect('changed', self.on_method_combo_changed)
		
		self.add(self.layout)
		
		self.show_all()
		
	def on_method_combo_changed(self, widget):
		self.chosen_method = widget.get_active()
		if self.chosen_method == 1:
			self.slider_k_adj.hide()
			self.l_k1.hide()
			self.l_k2.hide()
			self.l_prop.hide()
			self.l_nonprop.hide()
			self.l_sus.hide()
			self.l_indices.hide()
			self.entry_prop_indices.hide()
			self.entry_nonprop_indices.hide()
			self.entry_sus_indices.hide()
			self.layout.move(self.txt_entry_scroll, 6, 158)
			self.layout.move(self.button_anlz, 140, 278)
			self.layout.move(self.chbutton_translate, 8, 278)
			self.layout.move(self.score_label, 6, 260)
			
		else:
			self.show_all()
			self.layout.move(self.txt_entry_scroll, 6, 260)
			self.layout.move(self.button_anlz, 140, 380)
			self.layout.move(self.chbutton_translate, 8, 380)
			self.layout.move(self.score_label, 6, 362)
	
	def do_analysis(self, widget):
		global last_trained_model
		global last_trained_model1
		global last_tokenizer
		global last_tokenizer1
		
		maxlen1 = int(self.ml1_buff.get_text()) if len(self.ml1_buff.get_text()) >= 1 else 0
		maxlen2 = int(self.ml2_buff.get_text()) if len(self.ml2_buff.get_text()) >= 1 else 0
		
		if maxlen1 == 0 or maxlen2 == 0:
			return
		
		if self.last_loaded_model1_path != self.mpath_buf1.get_text():
			self.last_loaded_model1_path, last_trained_model = ld_model(self.mpath_buf1.get_text())
		if self.last_loaded_model2_path != self.mpath_buf2.get_text():
			self.last_loaded_model2_path, last_trained_model1 = ld_model(self.mpath_buf2.get_text())
		
		if self.last_loaded_tokenizer1_path != self.tpath_buf1.get_text():
			self.last_loaded_tokenizer1_path, last_tokenizer = ld_tokenizer(self.tpath_buf1.get_text())
		if self.last_loaded_tokenizer2_path != self.tpath_buf2.get_text():
			self.last_loaded_tokenizer2_path, last_tokenizer1 = ld_tokenizer(self.tpath_buf2.get_text())
		
		translate_toggled = self.chbutton_translate.get_active()
		text_nn1 = preprocessing.text_to_sequence(self.curtext_buffer.get_text(self.curtext_buffer.get_start_iter(), self.curtext_buffer.get_end_iter(), translate_toggled), last_tokenizer, maxlen1, False)
		text_nn2 = preprocessing.text_to_sequence(self.curtext_buffer.get_text(self.curtext_buffer.get_start_iter(), self.curtext_buffer.get_end_iter(), translate_toggled), last_tokenizer1, maxlen2, False)
		
		try:
			if self.chosen_method == 1:
				eval_result = evaluation.make_prediction_binary(last_trained_model, last_trained_model1, text_nn1, text_nn2)
				eval_result = localization.ret_label_string(eval_result)
			else:
				k1 = 0.5 - self.slider_k_adj.get_value()
				k2 = 0.5 + self.slider_k_adj.get_value()
				indices = [ get_indices(self.npi_buff.get_text()), get_indices(self.pi_buff.get_text()), get_indices(self.si_buff.get_text()) ]
				indices_sum = sum([i[1] - i[0] for i in indices])
				if indices_sum > 1.0 or indices_sum < 1.0:
					return
				
				score, label = evaluation.make_prediction_discrete(last_trained_model, last_trained_model1, text_nn1, text_nn2, k1, k2, indices)
				eval_result =  '{:.3f}, {}'.format(score, localization.ret_label_string(label))
				
			self.score_label.set_text("Оцінка допису: " + eval_result)
		except Exception as e:
			self.curtext_buffer.delete(self.curtext_buffer.get_start_iter(), self.curtext_buffer.get_end_iter())
			self.curtext_buffer.insert(self.curtext_buffer.get_end_iter(), str(e))
		
	
	def mselect1_invoke(self, widget):
		filename = dir_cdialog_invocation(self, "Вибрати модель №1...")
		if filename == None:
			return
		model_name = filename.replace('\\', '/').split('/')[-1]
		maxlen = "512"
		model_name_tokens = model_name.split('_')
		if model_name_tokens[0].isdigit():
			maxlen = model_name_tokens[0]
		self.mpath_buf1.set_text(filename, -1)
		self.ml1_buff.set_text(maxlen, -1)
	
	def mselect2_invoke(self, widget):
		filename = dir_cdialog_invocation(self, "Вибрати модель №2...")
		if filename == None:
			return
		model_name = filename.replace('\\', '/').split('/')[-1]
		maxlen = "512"
		model_name_tokens = model_name.split('_')
		if model_name_tokens[0].isdigit():
			maxlen = model_name_tokens[0]
		self.mpath_buf2.set_text(filename, -1)
		self.ml2_buff.set_text(maxlen, -1)
	
	def tselect1_invoke(self, widget):
		filename = file_cdialog_invocation(self, "Вибрати токенізатор №1...")
		if filename == None:
			return
		self.tpath_buf1.set_text(filename, -1)
	
	def tselect2_invoke(self, widget):
		filename = file_cdialog_invocation(self, "Вибрати токенізатор №2...")
		if filename == None:
			return
		self.tpath_buf2.set_text(filename, -1)

class MainWindow(Gtk.Window):
	def __init__(self):
		super().__init__(title = "Метод автоматизованого виявлення пропаганди")
		super().set_default_size(512, 256)
		
		self.layout = Gtk.Fixed()
		self.button_mlts = Gtk.Button(label="Перейти до налаштувань навчання")
		self.button_detc = Gtk.Button(label="Перейти до виявлення пропаганди")
		
		self.button_mlts.set_size_request(512, 128)
		self.button_detc.set_size_request(512, 128)
		self.layout.put(self.button_mlts, 0, 0)
		self.layout.put(self.button_detc, 0, 128)
		
		self.button_mlts.connect('clicked', self.open_ml_window)
		self.button_detc.connect('clicked', self.open_det_window)
		
		self.add(self.layout)
	
	def open_ml_window(self, widget):
		mlwin = MLSettingsWindow()
	def open_det_window(self, widget):
		detwin = DetectionWindow()

if __name__ == "__main__":
	win = MainWindow()
	win.connect("destroy", Gtk.main_quit)
	win.show_all()
	Gtk.main()
