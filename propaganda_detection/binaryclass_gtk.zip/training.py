import os
import tensorflow as tf
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense, Dropout, Bidirectional
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from tensorflow.keras.models import save_model
import numpy as np
import pickle
import re
import numpy as np

def train_gru(X_train, y_train, X_test, y_test, epochs, batch_size, embedding_dim, embedding_input_dim, units, maxlen, class_weights):
	model = tf.keras.Sequential([
		tf.keras.layers.Embedding(embedding_input_dim, embedding_dim, input_length=maxlen),
		tf.keras.layers.GRU(units=units, return_sequences=True),
		tf.keras.layers.GRU(units=int(units / 2), return_sequences=False),
		tf.keras.layers.Dropout(0.3),
		tf.keras.layers.Dense(2, activation='softmax', kernel_regularizer='l2')
	])
	
	lr_scheduler = tf.keras.callbacks.ReduceLROnPlateau(factor=0.5, patience=3, verbose=1)
	optimizer = tf.keras.optimizers.Adam(learning_rate=0.001)
	early_stopping = tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)
	
	model.compile(optimizer=optimizer, loss='sparse_categorical_crossentropy', metrics=['accuracy'])
	
	model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, validation_data=(X_test, y_test), callbacks=[lr_scheduler, early_stopping], class_weight=class_weights)
	
	return model

def train_bilstm(X_train, y_train, X_test, y_test, epochs, batch_size, embedding_dim, embedding_input_dim, units, maxlen, class_weights):
	model = tf.keras.Sequential([
		tf.keras.layers.Embedding(embedding_input_dim, embedding_dim, input_length=maxlen, trainable=False),
		tf.keras.layers.Bidirectional(tf.keras.layers.LSTM(units=units, return_sequences=True)),
		tf.keras.layers.Bidirectional(tf.keras.layers.LSTM(units=int(units / 2), return_sequences=False)),
		tf.keras.layers.Dropout(0.3),
		tf.keras.layers.Dense(2, activation='softmax', kernel_regularizer='l2')
	])
	
	lr_scheduler = tf.keras.callbacks.ReduceLROnPlateau(factor=0.5, patience=3, verbose=1)
	optimizer = tf.keras.optimizers.Adam(learning_rate=0.001)
	early_stopping = tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)
	
	model.compile(optimizer=optimizer, loss='sparse_categorical_crossentropy', metrics=['accuracy'])
	
	model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, validation_data=(X_test, y_test), callbacks=[lr_scheduler, early_stopping], class_weight=class_weights)
	
	return model
