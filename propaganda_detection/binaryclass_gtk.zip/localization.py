labels_uk = ['Допис без пропаганди', 'Пропагандистський допис', 'Підозрілий допис']
labels_en = ['Post without propaganda', 'Propaganda post', 'Suspicious post']

def ret_label_string(label_num, lang='uk'):
	if lang == 'uk':
		global labels_uk
		return labels_uk[label_num]
	if lang == 'en':
		global labels_en
		return labels_en[label_num]
	
	return '???'

