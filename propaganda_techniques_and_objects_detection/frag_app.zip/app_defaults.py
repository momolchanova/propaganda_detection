APP_CONFIG = {
	'QT_SCALE' : 1.0,		# default value
	'TEXT_LEVEL' : True,	# whether to classify full text (True) or individual sentences (False)
	'SENTENCE_REGEX' : r"[^.!?]+[.!?]\s*|[^.!?]+$",	# regular expression to split text to sentences if TEXT_LEVEL is False
	'CLASSES' : {},			# entries in format CLASS : { 'COLOR' : [R, G, B] or None, 'TEXT_COLOR' : [R, G, B] or None }
	'MODELS' : {},			# entries in format CLASS : { 'MODEL' : PATH, 'LOAD_AS' : 'BERT'/'RoBERTa'(regardless of casing), 'YOUDENS_J' : float or None, 'METRICS' : PATH }
	'LOCALIZATION' : {		# default localizations for UI elements
		"window_title" : "Manipulation Techniques Analysis",
		"label_input_text" : "Text for analysis:",
		"button_identify" : "Identify used manipulation techniques"
	}
}