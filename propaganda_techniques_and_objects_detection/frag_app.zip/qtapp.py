from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QTextEdit, QPushButton, QLabel
from PySide6.QtGui import QTextCharFormat, QColor, QFont
from PySide6.QtCore import Qt
import app_config
from app_models import ModelInterfacer
import re
import sys

LD_APP_CONFIG = {}

class TechniquesApp(QWidget):
	def __init__(self, argv):
		global LD_APP_CONFIG
		LD_APP_CONFIG = app_config.load_app_config(argv['CFG_PATH'])
		super().__init__()
		self.init_ui()
	
	def init_ui(self):
		layout = QVBoxLayout()
	
		self.textbox = QTextEdit()
		self.label_input = QLabel(LD_APP_CONFIG['LOCALIZATION']['label_input_text'])
		self.button_classify = QPushButton(LD_APP_CONFIG['LOCALIZATION']['button_identify'])
		self.output_box = QTextEdit()
		self.output_box.setReadOnly(True)
	
		layout.addWidget(self.label_input)
		layout.addWidget(self.textbox)
		layout.addWidget(self.button_classify)
		layout.addWidget(self.output_box)
	
		self.setLayout(layout)
		self.setWindowTitle(LD_APP_CONFIG['LOCALIZATION']['window_title'])
	
		self.resize_ui()
		if LD_APP_CONFIG['TEXT_LEVEL']:
			self.button_classify.clicked.connect(self.classify_text)
		else:
			self.button_classify.clicked.connect(self.classify_text_sentences)
		if 'DEMO' in LD_APP_CONFIG:
			self.textbox.setText(LD_APP_CONFIG['DEMO']['TEXT'])
			if LD_APP_CONFIG['TEXT_LEVEL']:
				self.postprocess(LD_APP_CONFIG['DEMO']['PREDICTIONS'])
			else:
				self.postprocess_sentences(LD_APP_CONFIG['DEMO']['PREDICTIONS'])

	def resize_ui(self):
		font = QFont()
		font.setPointSize(int(12 * LD_APP_CONFIG['QT_SCALE']))
		self.label_input.setFont(font)
		self.textbox.setFont(font)
		self.output_box.setFont(font)
		self.button_classify.setFont(font)
	
	def classify_text_sentences(self):
		text = self.textbox.toPlainText()
		results = self.make_predictions_sentences(text)
		self.postprocess_sentences(results)
	
	def classify_text(self):
		text = self.textbox.toPlainText()
		results = self.make_predictions(text)
		self.postprocess(results)
	
	def make_predictions(self, text):
		results = {}	# entries in style: CLASS : [predicted, confidence]
		
		for k, _ in LD_APP_CONFIG["CLASSES"].items():
			if k in LD_APP_CONFIG["MODELS"]:
				predicted_class, confidence = LD_APP_CONFIG["MODELS"][k].predict(text)
				results[k] = [predicted_class, confidence]
		
		return results
	
	def make_predictions_sentences(self, text):
		sentences = re.findall(LD_APP_CONFIG["SENTENCE_REGEX"], text)
		
		results = {}	# entries in style: sentence : [CLASS : [predicted, confidence]]
		
		for k, _ in LD_APP_CONFIG["CLASSES"].items():
			if k in LD_APP_CONFIG["MODELS"]:
				for sentence in sentences:
					predicted_class, confidence = LD_APP_CONFIG["MODELS"][k].predict(sentence)
					if sentence not in results:
						results[sentence] = []
					
					results[sentence].append({k : [predicted_class, confidence]})
		
		return results
	
	def postprocess_sentences(self, results):
		self.textbox.clear()
		self.output_box.clear()
		cursor = self.textbox.textCursor()
		default_fmt = QTextCharFormat()
		class_confidences = {class_name: [] for class_name in LD_APP_CONFIG["CLASSES"]}
		
		for sentence, classifications in results.items():
			best_class = None
			best_confidence = 0.0
			has_prediction = False
			
			for classification in classifications:
				for class_name, (predicted, confidence) in classification.items():
					if predicted:
						has_prediction = True
						if confidence > best_confidence:
							best_class = class_name
							best_confidence = confidence
			
			fmt = QTextCharFormat()
			if has_prediction and best_class:
				color = LD_APP_CONFIG["CLASSES"][best_class]["COLOR"]
				text_color = LD_APP_CONFIG["CLASSES"][best_class]["TEXT_COLOR"]
				if color is not None:
					fmt.setBackground(QColor(*color))
				if text_color is not None:
					fmt.setForeground(QColor(*text_color))
				class_confidences[best_class].append(best_confidence)
				cursor.insertText(sentence, fmt)
			else:
				cursor.insertText(sentence, default_fmt)
			
			cursor.insertText(" ")
		
		output_cursor = self.output_box.textCursor()
		output_cursor.setCharFormat(default_fmt)
		
		output_cursor.insertText("Confidence Statistics:\n")
		
		for class_name, confidences in class_confidences.items():
			if not confidences:
				continue
			class_fmt = QTextCharFormat()
			color = LD_APP_CONFIG["CLASSES"][class_name]["COLOR"]
			text_color = LD_APP_CONFIG["CLASSES"][class_name]["TEXT_COLOR"]
			if color is not None:
				class_fmt.setBackground(QColor(*color))
			if text_color is not None:
				class_fmt.setForeground(QColor(*text_color))
			
			output_cursor.insertText(class_name + ": ", class_fmt)
			output_cursor.setCharFormat(default_fmt)
			
			avg_confidence = sum(confidences) / len(confidences)
			output_cursor.insertText(f"Avg Confidence: {avg_confidence:.2f} (Model accuracy: {LD_APP_CONFIG['MODELS'][class_name].get_metric('accuracy'):.2f})\n")
	
	def postprocess(self, results):
		self.output_box.clear()
		
		output_cursor = self.output_box.textCursor()
		default_fmt = QTextCharFormat()
		output_cursor.setCharFormat(default_fmt)
		
		output_cursor.insertText("Confidence Statistics:\n")
		
		for class_name, (predicted, confidence) in results.items():
			fmt = QTextCharFormat()
			
			if predicted == 1:
				fmt.setBackground(QColor(145, 29, 52))
				fmt.setForeground(QColor("white"))
			
			output_cursor.setCharFormat(fmt)
			output_cursor.insertText(f"{class_name}: Confidence {confidence:.2f} (Model accuracy: {LD_APP_CONFIG['MODELS'][class_name].get_metric('accuracy'):.2f})\n")
		
		output_cursor.setCharFormat(default_fmt)
	
	


if __name__ == "__main__":
	i = 1
	argv = {
		'CFG_PATH' : "qtapp.cfg"
	}
	
	while i < len(sys.argv):
		if sys.argv[i] == "-cfg" and i + 1 < len(sys.argv):
			argv['CFG_PATH'] = sys.argv[i + 1]
			i += 1
		i += 1
	
	app = QApplication([])
	window = TechniquesApp(argv)
	window.show()
	app.exec()
