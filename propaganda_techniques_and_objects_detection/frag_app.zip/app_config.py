import os
import json
import app_defaults
from app_models import ModelInterfacer

def check_integrity(userdata):
	for k, v in app_defaults.APP_CONFIG.items():
		if k not in userdata:
			userdata[k] = v
	
	return userdata

def write_new_app_config(path):
	with open(path, 'w') as apc:
		json.dump(
			app_defaults.APP_CONFIG, 
			fp=apc,
			indent=4
		)

def load_app_config(path="qtapp.cfg"):
	if not os.path.exists(path):
		write_new_app_config(path)
	
	with open(path, 'r') as udf:
		config = check_integrity(json.load(udf))
		ld_config = { 
			'QT_SCALE' : config['QT_SCALE'],
			'TEXT_LEVEL' : config['TEXT_LEVEL'],
			'CLASSES' : config['CLASSES'],
			'SENTENCE_REGEX' : config['SENTENCE_REGEX'],
			'LOCALIZATION' : config['LOCALIZATION'],
			'MODELS' : {}
		}
		if 'DEMO' in config:
			ld_config['DEMO'] = config['DEMO']
		
		for k, v in config['MODELS'].items():
			if k in ld_config['CLASSES']:
				ld_config['MODELS'][k] = ModelInterfacer(v.get('MODEL', ''), v.get('LOAD_AS', 'bert'), v.get('YOUDENS_J', None), v.get('METRICS', None))
		
		return ld_config