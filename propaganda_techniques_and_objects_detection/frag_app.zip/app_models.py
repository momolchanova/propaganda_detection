import torch
import json
from transformers import BertTokenizer, BertForSequenceClassification, RobertaTokenizer, RobertaForSequenceClassification

def load_as_bert(path, what):
	if what == "model":
		model = BertForSequenceClassification.from_pretrained(path)
		device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
		model.eval()
		return device, model
	if what == "tokenizer":
		tokenizer = BertTokenizer.from_pretrained(path)
		return tokenizer

def load_as_roberta(path):
	if what == "model":
		model = RobertaForSequenceClassification.from_pretrained(path)
		device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
		model.eval()
		return device, model
	if what == "tokenizer":
		tokenizer = RobertaTokenizer.from_pretrained(path)
		return tokenizer

def load_model_metrics(path):
	important_metrics = ['accuracy', 'f1', 'precision', 'recall']
	metrics = {}
	
	with open(path, 'r') as mjs:
		ld_metrics = json.load(mjs)
		ld_metric_keys = {key.lower() : key for key in list(ld_metrics.keys())}
		
		for metric in important_metrics:
			if metric in ld_metric_keys:
				metrics[metric] = ld_metrics[ld_metric_keys[metric]]
			elif f"eval_{metric}" in ld_metric_keys:
				metrics[metric] = ld_metrics[ld_metric_keys[f"eval_{metric}"]]
			elif f"train_{metric}" in ld_metric_keys:
				metrics[metric] = ld_metrics[ld_metric_keys[f"train_{metric}"]]
		
	return metrics

class ModelInterfacer():
	def __init__(self, mpath, load_as, youdens_j_stat, model_metrics_path):
		self.model = None				# will be loaded model
		self.tokenizer = None			# will be loaded tokenizer
		self.youdens_j = youdens_j_stat if isinstance(youdens_j_stat, float) or youdens_j_stat is None else None
		self.device = "cpu"				# will be cuda, if user specs allow it
		self.metrics = None if model_metrics_path is None or not model_metrics_path else load_model_metrics(model_metrics_path)
		if load_as.lower() == 'bert':
			self.device, self.model = load_as_bert(mpath, "model")
			self.tokenizer = load_as_bert(mpath, "tokenizer")
		
		if load_as.lower() == 'roberta':
			self.device, self.model = load_as_roberta(mpath, "model")
			self.tokenizer = load_as_roberta(mpath, "tokenizer")
		
	def get_metric(self, metric):
		return self.metrics.get(metric, 0.0)
	
	def predict(self, text):
		"""
		Predicts the class of the given text using the trained model.
		
		:param text: The input text to classify
		:return: Predicted class label and confidence
		"""
		self.model.to(self.device)
		
		inputs = self.tokenizer(text, return_tensors="pt", padding=True, truncation=True, max_length=512)
		inputs = {key: val.to(self.device) for key, val in inputs.items()}
		
		with torch.no_grad():
			outputs = self.model(**inputs)
		
		logits = outputs.logits
		probs = torch.sigmoid(logits).cpu().numpy()
	
		if self.youdens_j is not None:
			predicted_class = 1 if probs[0][0] >= self.youdens_j else 0
			confidence = probs[0][0]
		else:
			predicted_class = int(probs[0][0] >= 0.5)
			confidence = probs[0][0]
	
		self.model.to("cpu")
		torch.cuda.empty_cache()
	
		return predicted_class, confidence
	